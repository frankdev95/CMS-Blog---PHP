<?php include "includes/db.php"; ?>
<?php include "includes/markup/header.php"; ?>
<?php include "includes/markup/nav.php"; ?>
<?php include "includes/markup/content.php"; ?>
<?php include "includes/markup/footer.php"; ?>
