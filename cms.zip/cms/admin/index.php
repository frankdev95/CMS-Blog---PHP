<?php include "includes/header.php"; ?>

<div id="wrapper">
    <?php include "includes/nav.php"; ?>
    <?php include "includes/page_wrapper.php"; ?>
</div>

<?php include "includes/footer.php"; ?>