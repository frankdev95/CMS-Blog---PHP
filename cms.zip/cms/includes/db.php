<?php include "functions.php";

$connection = mysqli_connect('localhost', 'root', 'root', 'cms');

show_error($connection);
?>